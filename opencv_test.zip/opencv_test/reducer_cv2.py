#!/usr/bin/env python3

#/usr/bin/python3
# -*-coding:utf-8 -*

import sys

for line in sys.stdin:
    print("Reducer: "+line)
