#!/bin/bash
#!/usr/bin/python3

#   comman to run it without hadoop:
#   [$]: cat file_names_docker.txt | python3 mapper_cv2.py  | python3 reducer_cv2.py

BASE_DIR="/home/usermr/examples/Projects/Python/opencv_test"
BASE_DIR="."

HADOOP_STREAM="/work/hadoop/hadoop-3.3.1/share/hadoop/tools/lib/hadoop-streaming-3.3.1.jar"

INPUT_DIRETORY="/home/usermr/examples/Projects/Python/opencv_test"
INPUT_FILE="file_names_hadoop.txt"

INPUT="/user/usermr/input/file_names_hadoop.txt"
OUTPUT="/user/usermr/output/final"
MAPPER="mapper_cv2.py"
REDUCER="reducer_cv2.py"

FILES="-file ${BASE_DIR}/mapper_cv2.py -file ${BASE_DIR}/reducer_cv2.py"

HADOP_PATH="${HADOOP_HOME}/bin/hadoop"

#   delete previous output
echo -e "\nRemoving previous output..."
CMD="hadoop fs -rm -f -r ${OUTPUT}"
echo -e "\n${CMD}"
${CMD}

hadoop fs -ls ${INPUT}

hadoop fs -cat ${INPUT}

echo ""

#   copying images' directory
#CMD="hadoop fs -put images_small /user/usermr/input"
#${CMD}

#   copying images txt file
CMD="hadoop fs -put -f file_names_hadoop.txt /user/usermr/input/"
${CMD}


#   bash problems, this command copied and pasted to terminal works just fine:
CMD="hadoop jar ${HADOOP_STREAM} -file ${MAPPER} -mapper 'python3 ${MAPPER}' -file ${REDUCER} -reducer 'python3 ${REDUCER}' -input ${INPUT} -output ${OUTPUT}"
echo ${CMD}

hadoop jar ${HADOOP_STREAM} -file ${MAPPER} -mapper "python3 ${MAPPER}" -file ${REDUCER} -reducer "python3 ${REDUCER}" -input ${INPUT} -output ${OUTPUT} -file "/home/usermr/.local/lib/python3.10/site-packages/cv2/cv2.abi3.so"

#-cmdenv "PYTHONPATH=/home/usermr/.local/lib/python3.10/"
#- "/home/usermr/.local/lib/python3.10/site-packages/cv2"

