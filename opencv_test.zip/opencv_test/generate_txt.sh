#!/bin/bash

CURR_DIR=$(pwd)

directory="${CURR_DIR}/images_small" # Replace this with the path to your directory
output_file="${CURR_DIR}/file_names_docker.txt"
# Check if the directory exists
if [ -d "$directory" ]; then
    # Navigate to the specified directory
    cd "$directory" || exit

    # List all files in the directory and save the names to a text file
    #ls -p | grep -v / > $output_file"
    #ls -d $PWD/* > $output_file 
    ls -p > $output_file
    
    echo "File names saved to $output_file"
else
    echo "Directory not found"
fi
