#!/usr/bin/env python3

#/usr/bin/python3
# -*-coding:utf-8 -*

import sys
import cv2

# Load the pre-trained Haar Cascade face detector
cascade_filename = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(cascade_filename)

def detect_face(image, scaleFactor, minNeighbors, minSize):
    image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(image_gray, scaleFactor=scaleFactor, minNeighbors=minNeighbors, minSize=minSize)
    return faces



scaleFactor = 1.2
minNeighbors = 1
minSize = (30, 30)

for line in sys.stdin:
    # Split the line into image name and face coordinates
    image_name=line.strip()

    # Detect faces using Haar Cascade in the image
    image = cv2.imread(image_name)
    image_f=image_name.split("/")[-2:]
    elo=image_f[0]+"/"+image_f[1]
    
    if image is not None:
        faces = detect_face(image, scaleFactor, minNeighbors, minSize)

        # Emit each face's image name and coordinates
        for face in faces:
            print(f"{elo},{','.join(map(str, face))}")
