#!/usr/bin/env python3

#/usr/bin/python3
# -*-coding:utf-8 -*

import sys
#import zipimport

for line in sys.stdin:
    # Split the line into image name and face coordinates
    image_name=line.strip()
    #image = cv2.imread(image_name)
    print("Mapper: "+image_name)