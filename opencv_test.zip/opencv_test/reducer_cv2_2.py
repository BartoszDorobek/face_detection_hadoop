#!/usr/bin/env python3

#/usr/bin/python3
# -*-coding:utf-8 -*

import sys

img_prev=""
faces=0
for line in sys.stdin:
    (img_name, x, y, w, h) = line.strip().split(",")

    if img_prev=="":
        img_prev=img_name
        faces+=1
    elif img_name==img_prev:
        faces+=1
    else:
        #print("No. of faces on image "+img_prev+": "+str(faces))
        print(img_prev, faces)
        faces=1
        img_prev=img_name

# for the last line
#print("No. of faces on image "+img_prev+": "+str(faces))
print(img_prev, faces)
