#!/bin/bash

#   For bad interpreter error:
#   [$]: sed -i 's/\r$//' modify_txt.sh


# Check if filename is provided as an argument
if [ $# -ne 2 ]; then
    echo "Usage: $0 <input_filename> <output_filename>"
    exit 1
fi

input_file=$1
output_file=$2

# Check if the input file exists
if [ ! -f "$input_file" ]; then
    echo "File '$input_file' not found!"
    exit 1
fi

tempfile=$(mktemp)  # Create a temporary file

# Prepend "string1" to each line of the input file and save it to a new file
while IFS= read -r line; do
    echo "/user/usermr/input/images_small/$line" >> "$tempfile"
done < "$input_file"

# Move the modified content to the output file
mv "$tempfile" "$output_file"

echo "Prepending 'string1' to each line in '$input_file' and saved to '$output_file'."
