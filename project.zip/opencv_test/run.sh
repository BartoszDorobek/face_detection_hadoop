#!/bin/bash
#!/usr/bin/python3

#   comman to run it without hadoop:
#   [$]: cat file_names_docker.txt | python3 mapper_cv2.py  | python3 reducer_cv2.py


HADOOP_STREAM="/work/hadoop/hadoop-3.3.1/share/hadoop/tools/lib/hadoop-streaming-3.3.1.jar"

INPUT="/user/usermr/input/file_names_hadoop.txt"
OUTPUT="/user/usermr/output/final"
MAPPER="mapper_cv2.py"
REDUCER="reducer_cv2.py"
FILES="-file ./mapper_cv2.py -file ./reducer_cv2.py"
HADOP_PATH="${HADOOP_HOME}/bin/hadoop"

#   delete previous output
echo -e "\nRemoving previous output..."
CMD="hadoop fs -rm -f -r ${OUTPUT}"
echo -e "\n${CMD}"
${CMD}

#   copying images' directory
CMD="hadoop fs -put images_small /user/usermr/input"
${CMD}

#   copying images txt file
CMD="hadoop fs -put file_names_hadoop.txt /user/usermr/input/"
${CMD}


#   bash problems, this command copied and pasted to terminal works just fine:
hadoop jar ${HADOOP_STREAM} -file ${MAPPER} -mapper "python3 ${MAPPER}" -file ${REDUCER} -reducer "python3 ${REDUCER}" -input ${INPUT} -output ${OUTPUT}

